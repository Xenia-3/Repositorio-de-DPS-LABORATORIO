import React, { useState } from 'react';
import {
  View,
  Text,
  FlatList,
  TouchableOpacity,
  Image,
  StyleSheet,
  ScrollView,
  TextInput,
} from 'react-native';

const paisesPrueba = [
  {
    cca3: '1',
    name: { common: 'México' },
    capital: ['Ciudad de México'],
    population: '128 millones',
    region: 'América',
    subregion: 'América del Norte',
    language: 'Español',
    currency: 'Peso Mexicano',
    area: '1,964,375 km²',
    timezone: 'UTC -6',
    independence: '1810',
    famousFood: 'Tacos',
    flags: {
      png: 'https://flagcdn.com/w320/mx.png',
    },
  },

  {
    cca3: '2',
    name: { common: 'España' },
    capital: ['Madrid'],
    population: '48 millones',
    region: 'Europa',
    subregion: 'Europa del Sur',
    language: 'Español',
    currency: 'Euro',
    area: '505,990 km²',
    timezone: 'UTC +1',
    independence: '1492',
    famousFood: 'Paella',
    flags: {
      png: 'https://flagcdn.com/w320/es.png',
    },
  },

  {
    cca3: '3',
    name: { common: 'Argentina' },
    capital: ['Buenos Aires'],
    population: '46 millones',
    region: 'América',
    subregion: 'América del Sur',
    language: 'Español',
    currency: 'Peso Argentino',
    area: '2,780,400 km²',
    timezone: 'UTC -3',
    independence: '1816',
    famousFood: 'Asado',
    flags: {
      png: 'https://flagcdn.com/w320/ar.png',
    },
  },

  {
    cca3: '4',
    name: { common: 'Colombia' },
    capital: ['Bogotá'],
    population: '52 millones',
    region: 'América',
    subregion: 'América del Sur',
    language: 'Español',
    currency: 'Peso Colombiano',
    area: '1,141,748 km²',
    timezone: 'UTC -5',
    independence: '1810',
    famousFood: 'Arepas',
    flags: {
      png: 'https://flagcdn.com/w320/co.png',
    },
  },

  {
    cca3: '5',
    name: { common: 'Chile' },
    capital: ['Santiago'],
    population: '19 millones',
    region: 'América',
    subregion: 'América del Sur',
    language: 'Español',
    currency: 'Peso Chileno',
    area: '756,102 km²',
    timezone: 'UTC -4',
    independence: '1818',
    famousFood: 'Empanadas',
    flags: {
      png: 'https://flagcdn.com/w320/cl.png',
    },
  },

  {
    cca3: '6',
    name: { common: 'Perú' },
    capital: ['Lima'],
    population: '34 millones',
    region: 'América',
    subregion: 'América del Sur',
    language: 'Español',
    currency: 'Sol Peruano',
    area: '1,285,216 km²',
    timezone: 'UTC -5',
    independence: '1821',
    famousFood: 'Ceviche',
    flags: {
      png: 'https://flagcdn.com/w320/pe.png',
    },
  },

  {
    cca3: '7',
    name: { common: 'Venezuela' },
    capital: ['Caracas'],
    population: '28 millones',
    region: 'América',
    subregion: 'América del Sur',
    language: 'Español',
    currency: 'Bolívar',
    area: '916,445 km²',
    timezone: 'UTC -4',
    independence: '1811',
    famousFood: 'Arepas',
    flags: {
      png: 'https://flagcdn.com/w320/ve.png',
    },
  },

  {
    cca3: '8',
    name: { common: 'Ecuador' },
    capital: ['Quito'],
    population: '18 millones',
    region: 'América',
    subregion: 'América del Sur',
    language: 'Español',
    currency: 'Dólar Estadounidense',
    area: '283,561 km²',
    timezone: 'UTC -5',
    independence: '1809',
    famousFood: 'Encebollado',
    flags: {
      png: 'https://flagcdn.com/w320/ec.png',
    },
  },
];

export default function App() {
  const [paisSeleccionado, setPaisSeleccionado] = useState(null);
  const [busqueda, setBusqueda] = useState('');

  const paisesFiltrados = paisesPrueba.filter((pais) =>
    pais.name.common.toLowerCase().includes(busqueda.toLowerCase())
  );

  // PANTALLA DE DETALLES
  if (paisSeleccionado) {
    return (
      <ScrollView style={styles.container}>
        <TouchableOpacity
          style={styles.botonVolver}
          onPress={() => setPaisSeleccionado(null)}
        >
          <Text style={styles.textoBoton}>← Volver</Text>
        </TouchableOpacity>

        <View style={styles.header}>
          <Image
            source={{ uri: paisSeleccionado.flags.png }}
            style={styles.banderaGrande}
          />

          <Text style={styles.nombrePais}>
            {paisSeleccionado.name.common}
          </Text>

          <Text style={styles.capital}>
            Capital: {paisSeleccionado.capital[0]}
          </Text>
        </View>

        <View style={styles.infoBox}>
          <Text style={styles.tituloInfo}>📋 Información General</Text>

          <Text style={styles.infoTexto}>
            🌎 Región: {paisSeleccionado.region}
          </Text>

          <Text style={styles.infoTexto}>
            🗺️ Subregión: {paisSeleccionado.subregion}
          </Text>

          <Text style={styles.infoTexto}>
            👥 Población: {paisSeleccionado.population}
          </Text>

          <Text style={styles.infoTexto}>
            🗣️ Idioma: {paisSeleccionado.language}
          </Text>

          <Text style={styles.infoTexto}>
            💰 Moneda: {paisSeleccionado.currency}
          </Text>

          <Text style={styles.infoTexto}>
            📏 Área: {paisSeleccionado.area}
          </Text>

          <Text style={styles.infoTexto}>
            ⏰ Zona horaria: {paisSeleccionado.timezone}
          </Text>

          <Text style={styles.infoTexto}>
            🎉 Independencia: {paisSeleccionado.independence}
          </Text>

          <Text style={styles.infoTexto}>
            🍴 Comida famosa: {paisSeleccionado.famousFood}
          </Text>
        </View>
      </ScrollView>
    );
  }

  // PANTALLA PRINCIPAL
  return (
    <View style={styles.container}>
      <View style={styles.headerLista}>
        <Text style={styles.titulo}>🌍 Países del Mundo</Text>

        <Text style={styles.subtitulo}>
          Explora información de cada país
        </Text>

        <TextInput
          style={styles.input}
          placeholder="Buscar país..."
          value={busqueda}
          onChangeText={setBusqueda}
        />
      </View>

      <FlatList
        data={paisesFiltrados}
        keyExtractor={(item) => item.cca3}
        showsVerticalScrollIndicator={false}
        renderItem={({ item }) => (
          <TouchableOpacity
            style={styles.tarjeta}
            onPress={() => setPaisSeleccionado(item)}
          >
            <Image
              source={{ uri: item.flags.png }}
              style={styles.bandera}
            />

            <View style={styles.infoTarjeta}>
              <Text style={styles.nombreLista}>
                {item.name.common}
              </Text>

              <Text style={styles.capitalLista}>
                Capital: {item.capital[0]}
              </Text>
            </View>

            <Text style={styles.flecha}>→</Text>
          </TouchableOpacity>
        )}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f2f4f7',
  },

  headerLista: {
    backgroundColor: '#2c3e50',
    paddingTop: 50,
    paddingBottom: 25,
    paddingHorizontal: 20,
    borderBottomLeftRadius: 25,
    borderBottomRightRadius: 25,
    alignItems: 'center',
  },

  titulo: {
    fontSize: 30,
    fontWeight: 'bold',
    color: 'white',
  },

  subtitulo: {
    fontSize: 15,
    color: '#d0d3d4',
    marginTop: 8,
    marginBottom: 15,
  },

  input: {
    backgroundColor: 'white',
    width: '100%',
    borderRadius: 12,
    paddingHorizontal: 15,
    paddingVertical: 12,
    fontSize: 16,
  },

  tarjeta: {
    flexDirection: 'row',
    backgroundColor: 'white',
    marginHorizontal: 15,
    marginVertical: 8,
    padding: 15,
    borderRadius: 15,
    alignItems: 'center',

    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.08,
    shadowRadius: 4,
    elevation: 3,
  },

  bandera: {
    width: 65,
    height: 45,
    borderRadius: 6,
    borderWidth: 1,
    borderColor: '#ddd',
    marginRight: 15,
  },

  infoTarjeta: {
    flex: 1,
  },

  nombreLista: {
    fontSize: 19,
    fontWeight: 'bold',
    color: '#2c3e50',
  },

  capitalLista: {
    marginTop: 4,
    fontSize: 14,
    color: '#7f8c8d',
  },

  flecha: {
    fontSize: 24,
    color: '#bdc3c7',
  },

  botonVolver: {
    backgroundColor: '#3498db',
    marginTop: 45,
    marginHorizontal: 15,
    padding: 14,
    borderRadius: 12,
    alignItems: 'center',
  },

  textoBoton: {
    color: 'white',
    fontSize: 16,
    fontWeight: 'bold',
  },

  header: {
    backgroundColor: '#2c3e50',
    alignItems: 'center',
    padding: 30,
    borderBottomLeftRadius: 25,
    borderBottomRightRadius: 25,
  },

  banderaGrande: {
    width: 180,
    height: 120,
    borderRadius: 12,
    borderWidth: 2,
    borderColor: 'white',
    marginBottom: 20,
  },

  nombrePais: {
    fontSize: 32,
    fontWeight: 'bold',
    color: 'white',
    textAlign: 'center',
  },

  capital: {
    marginTop: 8,
    fontSize: 18,
    color: '#d0d3d4',
  },

  infoBox: {
    backgroundColor: 'white',
    margin: 15,
    padding: 22,
    borderRadius: 18,

    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.08,
    shadowRadius: 4,
    elevation: 3,
  },

  tituloInfo: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#2c3e50',
    marginBottom: 20,
    textAlign: 'center',
  },

  infoTexto: {
    fontSize: 17,
    color: '#444',
    marginVertical: 8,
    lineHeight: 24,
  },
});